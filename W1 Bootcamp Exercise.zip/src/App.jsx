import React from 'react'

function App() {
  return (
    <div className= 'flex justify-center w-full min-h-screen bg-gray-800 text-white'>
     
     <header className='absolute top-0 text-xl p-5 bg-gray-600 w-full text-center rounded-lg'>
     To-DoList App
     </header>

    <main className='pt-36 w-3/4'>
    {/*User Promt */}
    <div className= 'flex justify-center'>
      <input className='bg-slate-700 p-4 rounded-2xl w-3/4 shadow-md' placeholder='Type your text here'>
      </input>
      <button className='pl-2 h-12 pt-2'>
        <img src='/logo192.png' alt="enter" className='w-full h-full'/>
      </button>
    </div>
    </main>
    </div>
  )
}

export default App
