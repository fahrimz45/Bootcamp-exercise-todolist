# Getting Started with AIgnite!

Use this repository to get right into the coding process.
Make sure to have node.js installed and a code-editing software present.
You are not allowed to code with notepad.