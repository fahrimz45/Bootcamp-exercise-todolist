import React from 'react'
import { useState, useEffect } from 'react';

function App() {

  const [task, setTask] = useState([
{ 
  title: 'Fisika Listrik Class',
  description: 'fisika listrik sulit',
  date: 'Setiap hari rabu',
  time: '16.00',
  status: 'Active',
  completed: false,
},
{ 
  title: 'Kelas Organisasi Arsitektur Komputer',
  description: 'OAK UTS',
  date: 'Hari Jumat depan',
  time: '13.00',
  status: 'Active',
  completed: false,
},
{ title: 'Mabim',
  description: 'forum',
  date: 'Setiap hari sabtu',
  time: 'All day',
  status: 'Active',
  completed: false,
}
]
)

const [newTask, setNewTask] = useState("")

const now = new Date()
const checked = false

const handleAddTask = () => {
  let taskToBeAdded  = {
    title: newTask,
    date: now.toLocaleDateString(),
    time: now.toLocaleTimeString(),
    status: "Active",
    completed: false,
  }
    setTask([...task, taskToBeAdded])
    setNewTask("")
  }

  function handleInputChange(e){
    setNewTask(e.target.value)
  }

  function handleToggleCompletion(index){
    const updatedTask = task.map((task, i) => i === index ? {...task, completed: !task.completed} : task)
    setTask(updatedTask)
  }

  function handleRemoveTask(index){
    const updatedTask = task.filter((_, i) => i !== index)
    setTask(updatedTask)
  }

  return (

    <div className= 'flex justify-center w-full min-h-screen bg-gray-800 text-white'>

     <header className='absolute top-0 text-xl p-5 bg-gray-600 w-full text-center rounded-lg'>
     To-DoList App
     </header>

    <main className='pt-32 w-3/4'>
    
 {/*User Promt*/}
    <div className= 'flex justify-center'>
      <input 
      className='bg-slate-700 p-4 rounded-2xl w-3/4 shadow-md' 
      placeholder='Type your text here'
      value = {newTask}
      onChange = {handleInputChange}>
      </input> 

      <button className='pl-2 h-12 pt-2'>
        <img src='/logo192.png' 
        alt="enter" 
        className='w-full h-full hover:contrast-150'
        onClick = {handleAddTask}/>
      </button>
    </div>

{/*just some spacing (padding) */}
<div className='p-6'> </div>

{/*to do list*/}
<div className='flex justify-center'>
  <div className= 'w-[80%] flex flex-col gap-y-4'> 
  <p className='font-semibold text-2xl'> To-Do List </p> 
  <hr/>

{task.map((currentTask, index) => (
  <div key={index} className=' bg-slate-900 p-4 rounded-2xl shadow-lg' >
<p className={currentTask.completed ? 'text-base line-through text-gray-500': 'text-base'}
>
  <span className= 'text-xl font-semibold' >
    {currentTask.title}
    </span><br/>
  {currentTask.description}
  <br/><br/>
  Date: {currentTask.date}
  <br/>
  Time: {currentTask.time}
  <br/>
  Status: {currentTask.status}
</p>

<input 
type='checkbox'
className="scale-[110%]"
checked={task.completed}
onChange={() => handleToggleCompletion(index)}>
</input>


<div className= 'relative flex justify-end'>
<button 
className= ' absolute bottom-0 bg-red-700 px-4 py-2 rounded-xl shadow-lg hover:bg-red-600'
onClick={() => handleRemoveTask(index)}> Remove
</button>

</div>
</div>

))}

{task.length === 0 ? <p className='text-l'> No tasks yet~</p> : null}

</div>

  </div>





<div className='p-1'> </div>

  </main>
</div>


  )
}

export default App
