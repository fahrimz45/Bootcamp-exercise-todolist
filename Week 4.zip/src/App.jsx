import React from 'react'
import { useState, useEffect } from 'react';
import axios from 'axios';

function App() {

  // local storage test


  const [task, setTask] = useState(() => {
  const taskLoad = localStorage.getItem("taskSave");
  return taskLoad ? JSON.parse(taskLoad) : [
    { 

  title: 'Fisika Listrik Class',
  description: 'Weekly electrical physics class',
  date: '12/11/2025',
  time: '16.00',
  status: 'Active',
  completed: false,
  fallback: false,
},
{ 
  title: 'Kelas Organisasi Arsitektur Komputer',
  description: 'UTS',
  date: '7/11/2025',
  time: '13.00',
  status: 'Active',
  completed: false,
  fallback: false,
},
{ title: 'Mabim',
  description: 'Forum',
  date: '8/11/2025',
  time: '07.00',
  status: 'Active',
  completed: false,
  fallback: false
}
]
  }
)

useEffect(() => {
  localStorage.setItem("taskSave", JSON.stringify(task))
  console.log("Tasks updated", (task))
}, [task]);


const [newTask, setNewTask] = useState("")

const now = new Date()
let checked = false

const extractTime = (text) => {
  const timePatterns = [/(\d{1,2}):(\d{2})\s*(AM|PM)/i, /(\d{1,2}):(\d{2})/, /(\d{1,2})\s*(AM|PM)/i];

 for (const pattern of timePatterns) {
    const match = text.match(pattern);
     if (match) {
      let hours = parseInt(match[1]);
      const minutes = match[2] ? parseInt(match[2]) : 0;
      const period = match[3];

      if (period && period.toUpperCase() === 'PM' && hours !== 12) {
        hours += 12;
      } else if (period && period.toUpperCase() === 'AM' && hours === 12) {
        hours = 0;
      }

  return `${hours.toString().padStart(2,'0')}:${minutes.toString().padStart(2, '0')}`;
   }
  }
 return null;
 };

const getNextDay = (dayName) => {
  const today = new Date()
  const currentDay = today.getDay()

  const dayMap = {
"minggu" : 0, "sunday": 0,
"senin": 1, "monday": 1,
"selasa": 2, "tuesday": 2,
"rabu": 3, "wednesday": 3,
"kamis": 4, "thursday" : 4,
"jumat": 5, "friday" : 5,
"sabtu": 6, "saturday" : 6,
  
  }
  
  const targetDay = dayMap[dayName.toLowerCase()]
  if (targetDay === undefined) return today

  const dayUntilTarget = (targetDay - currentDay + 7) % 7

  const nextDate = new Date(today)
  nextDate.setDate(today.getDate() + (dayUntilTarget === 0 ? 7 : dayUntilTarget))

  return nextDate
  
}

const handleAddTask = async () => {
  if (!newTask) return
  const today = new Date()

  let extractedTask = newTask
  let extractedDescription = ""
  let extractedDate = today.toLocaleDateString('id-ID')
  let extractedTime = today.toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit'})
  let FallBack = false
  
   try {
      const response = await axios.post(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
        {
          contents: [
            {
              parts: [
                {
                  text: `
You are an intelligent task parser that extracts structured information from user input for a to-do list app.
Your job is to analyze natural language text and output *only* a valid JSON object following the exact schema below:


{
  "task": "string",
  "description": "string",
  "date": "ISO 8601 format (YYYY-MM-DD)",
  "time": "HH:mm (24-hour format, optional)"
}


---


Examples:
Input:
"Work on Calculus tomorrow at 3 PM, there are 20 questions."


Output:
{
  "task": "Work on calculus",
  "description": "20 questions.",
  "date": "2025-11-03",
  "time": "15:00"
}


---


Now process this input:
"${newTask}"


Current date context: ${today.toISOString().split('T')[0]} (today is ${today.toLocaleDateString('en-US', {
                    weekday: 'long',
                  })})


Output only the JSON — no explanations, no extra text.
`,
                },
              ],
            },
          ],
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': process.env.REACT_APP_GEMINI_API_KEY,
          },
        }
      );

       const aiText = response.data.candidates[0].content.parts[0].text.trim();
      const cleanJson = aiText
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .trim();
      const parsed = JSON.parse(cleanJson);

      if (parsed.task) extractedTask = parsed.task
      if (parsed.description) extractedDescription = parsed.description
        else extractedDescription = ""
      if (parsed.date) extractedDate = new Date(parsed.date).toLocaleDateString('id-ID')
      if (parsed.time) extractedTime = parsed.time
      
    } catch (error){
        console.error("Ai Api failed..");

        // fallback if api fails
        
        const now = new Date()

        FallBack = true
        extractedTask = newTask
        extractedDescription = "(fallback used)"
        extractedDate = now.toLocaleDateString('id-ID')
        extractedTime = now.toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit'})

        const taskTest = newTask.toLocaleLowerCase()
        const days = ["minggu", "senin", "selasa", "rabu", "kamis", "jumat", "sabtu",]

        for (const day of days){
          if (taskTest.includes(day)) {
            const nextDayDate = getNextDay (day)
            extractedDate = nextDayDate.toLocaleDateString('id-ID')
            break
          }
        }
    const localTime = extractTime(taskTest)
    if (localTime) extractedTime = localTime

    }

const taskToAdd = {
  title: extractedTask,
  description: extractedDescription,
  date: extractedDate,
  time: extractedTime,
  status: "Active",
  completed: false,
  fallback: FallBack
}

setTask([...task, taskToAdd])
setNewTask("")

  
  }

  function handleInputChange(e){
    setNewTask(e.target.value)
  }

  function handleToggleCompletion(index){
    const updatedTask = task.map((task, i) => i === index ? {...task, completed: !task.completed} : task)
    setTask(updatedTask)
  }

  function handleRemoveTask(index){
    const updatedTask = task.filter((_, i) => i !== index)
    setTask(updatedTask)
  }


  return (

    <div className= 'flex justify-center w-full min-h-screen bg-gray-800 text-white'>

     <header className='absolute top-0 text-xl p-5 bg-gray-600 contrast-[130%] w-full text-center rounded-lg'>
     To-Do List App
     </header>

    <main className='pt-32 w-3/4'>
    
 {/*User Promt*/}
    <div className= 'flex justify-center'>
      <input 
      className='bg-slate-700 p-4 rounded-2xl w-3/4 shadow-md hover:contrast-[95%]' 
      placeholder='Type your text here'
      value = {newTask}
      onChange = {handleInputChange}>
      </input> 

      <button className='pl-2 h-12 pt-2'>
        <img src='/logo192.png' 
        alt="enter" 
        className='w-full h-full hover:contrast-[200%]'
        onClick = {handleAddTask}/>
      </button>
    </div>

{/*just some spacing (padding) */}
<div className='p-6'> </div>

{/*to do list*/}
<div className='flex justify-center'>
  <div className= 'w-[80%] flex flex-col gap-y-4'> 
  <p className='font-semibold text-2xl'> 💭 To-Do List </p> 
  <hr/>

{task.map((currentTask, index) => (
  <div key={index} className='bg-slate-900 p-4 rounded-2xl shadow-lg hover:contrast-[101%]' >
<p className={currentTask.completed ? 'text-base line-through text-gray-500': 'text-base'}
>
  <span className= 'text-xl font-semibold' >
    {currentTask.title}
    </span><br/>
  <span className={currentTask.fallback ? 'text-gray-500' : ''}>{currentTask.description}</span>
  <br/><br/>
  Date: {currentTask.date}
  <br/>
  Time: {currentTask.time}
  <br/>
  Status: {currentTask.status}
</p>

<input 
type='checkbox'
className="scale-[110%]"
checked={task.completed}
onChange={() => handleToggleCompletion(index)}>
</input>


<div className= 'relative flex justify-end'>
<button 
className= ' absolute bottom-0 bg-red-700 px-4 py-2 rounded-xl shadow-lg hover:bg-red-600'
onClick={() => handleRemoveTask(index)}> Remove
</button>

</div>
</div>

))}

{task.length === 0 ? <p className='text-l'> No tasks yet~</p> : ''}

</div>

  </div>





<div className='p-1'> </div>

  </main>
</div>


  )

}

export default App
