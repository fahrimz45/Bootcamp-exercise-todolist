import React from 'react'

function App() {

  const task = [
{ 
  title: 'Fisika Listrik Class',
  description: 'fisika listrik sulit',
  date: 'Setiap hari rabu',
  time: '16.00',
  status: 'Active',
},
{ 
  title: 'Kelas Organisasi Arsitektur Komputer',
  description: 'OAK UTS',
  date: 'Hari Jumat depan',
  time: '13.00',
  status: 'Active',
},
{ title: 'Mabim',
  description: 'forum',
  date: 'Setiap hari sabtu',
  time: 'All day',
  status: 'Active',
}
]

  return (

    <div className= 'flex justify-center w-full min-h-screen bg-gray-800 text-white'>

     <header className='absolute top-0 text-xl p-5 bg-gray-600 w-full text-center rounded-lg'>
     To-DoList App
     </header>

    <main className='pt-32 w-3/4'>
    
    {/*User Promt*/}
    <div className= 'flex justify-center'>
      <input className='bg-slate-700 p-4 rounded-2xl w-3/4 shadow-md' placeholder='Type your text here'>
      </input>
      <button className='pl-2 h-12 pt-2'>
        <img src='/logo192.png' alt="enter" className='w-full h-full'/>
      </button>
    </div>

{/*just some spacing (padding) */}
<div className='p-6'> </div>

{/*to do list */}
<div className='flex justify-center'>
  <div className= 'w-[80%] flex flex-col gap-y-4'>
  <p className='font-semibold text-2xl'> To-Do List </p> 
  <hr/>

{task.map((currentTask, index) => (
  <div key={index} className='bg-slate-900 p-4 rounded-2xl shadow-lg'>
<p className= 'text-base'>
  <span className= 'text-xl font-semibold'>
    {currentTask.title}
    </span><br/>
  {currentTask.description}
  <br/><br/>
  Date: {currentTask.date}
  <br/>
  Time: {currentTask.time}
  <br/>
  Status: {currentTask.status}
</p>
<br/>
<input type='checkbox'/>
</div>))}
</div>
  </div>

<div className='p-1'> </div>

  </main>
</div>


  )
}

export default App
